<html>
<head>
	<link rel="stylesheet" href="G22_footer.css">
</head>

<body>
	<div style="clear:both"></div>	
	<div id="footer">
		<p>© MYNottingham Library 2022 | All rights reserved</p>
	</div>
</body>

</html>